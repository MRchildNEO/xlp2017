function [XYZ,flag_next]=impact_configure2(xyz)

global theta R L SIDES pause_time arfa0 beta0 mu0
global x_A y_A x_B y_B Mass mass I_A I_C g theta_AEO

row=length(xyz);
arfa=xyz(row,1)-theta_AEO;
beta=xyz(row,2)-pi;
darfa=xyz(row,3);
dbeta=xyz(row,4);

% point_p=[-R*sin(arfa);-R*cos(arfa);0];
% 
% A_Xx=[cos(arfa),-sin(arfa),0;sin(arfa),cos(arfa),0;0,0,1];
% A_Xx1=[cos(beta),-sin(beta),0;sin(beta),cos(beta),0;0,0,1];
% 
% point_a=[x_A;y_A;0];
% point_b=[x_B;y_B;0];
% 
% r_pa=point_a-point_p;
% r_pb=point_b-point_p;
% r_ba=point_a-point_b;
% 
% R_PA=A_Xx*r_pa;
% R_PB=A_Xx*r_pb;  
% R_BA=A_Xx*r_ba;
% 
% r_dc=[-L/2;0;0];
% R_DC=A_Xx1*r_dc;
% R_DB=2*A_Xx1*r_dc;
% omega2=[0;0;dbeta];
% omega1=[0;0;darfa];
% 
% %��ײǰһ˲ʱ�������ٶ�
% V_C=cross(omega2,R_DC)
% V_B=cross(omega2,R_DB);
% V_A=V_B+cross(omega1,R_BA)
% 
% V_C1 =[  1/2*dbeta*sin(beta)*L;
% -1/2*dbeta*cos(beta)*L;
%                       0]
%                   
% V_A1 =[  dbeta*sin(beta)*L-darfa*(sin(arfa)*(x_A-x_B)+cos(arfa)*(y_A-y_B));
%  -dbeta*cos(beta)*L+darfa*(cos(arfa)*(x_A-x_B)-sin(arfa)*(y_A-y_B));
%                                                                   0]
 
% % v_A=[-R_PA(2)*darfa;R_PA(1)*darfa;0]
% % v_B=[-R_PB(2)*darfa;R_PB(1)*darfa;0]
% % 
% % 
% % v_Cr=L*dbeta*[-sin(beta);cos(beta);0]
% % 
% % v_C=v_B+v_Cr
% 
% [r_AB_X,v_A,v_C,angle]=solve_velocity(xyz);
% 
% arfa=angle(1);
% beta=-angle(2);
% darfa=-angle(3);
% dbeta=-angle(4);
% 
% v_Cx=v_C(1);
% v_Cy=v_C(2);
% v_Ax=v_A(1);
% v_Ay=v_A(2);
% 
% A_Xx=[cos(arfa),-sin(arfa),0;sin(arfa),cos(arfa),0;0,0,1];
% rr=[r_AB_X(1);r_AB_X(2);0];
% 
% newrr=A_Xx*rr;
% 
% ABx=newrr(1); % AB in XY
% ABy=newrr(2); % AB in XY
% 
AA=[                                                             I_A,                                                               0,         cos(arfa)*(x_A+R*sin(arfa))-sin(arfa)*(y_A+R*cos(arfa)),        -sin(arfa)*(x_A+R*sin(arfa))-cos(arfa)*(y_A+R*cos(arfa)),                         sin(arfa)*(x_A-x_B)+cos(arfa)*(y_A-y_B),                        -cos(arfa)*(x_A-x_B)+sin(arfa)*(y_A-y_B);
Mass*(-sin(arfa)*(x_A+R*sin(arfa))-cos(arfa)*(y_A+R*cos(arfa))),                                                               0,                                                               0,                                                              -1,                                                               1,                                                               0;
Mass*(cos(arfa)*(x_A+R*sin(arfa))-sin(arfa)*(y_A+R*cos(arfa))),                                                               0,                                                              -1,                                                               0,                                                               0,                                                               1;
                                                             0,                                                             I_C,                                                               0,                                                               0,                                                -1/2*sin(beta)*L,                                                 1/2*cos(beta)*L;
mass*(-sin(arfa)*(x_B+R*sin(arfa))-cos(arfa)*(y_B+R*cos(arfa))),                                           -1/2*mass*sin(beta)*L,                                                               0,                                                               0,                                                              -1,                                                               0;
mass*(cos(arfa)*(x_B+R*sin(arfa))-sin(arfa)*(y_B+R*cos(arfa))),                                            1/2*mass*cos(beta)*L,                                                               0,                                                               0,                                                               0,                                                              -1];
 

BB=[                                                          I_A*darfa;
Mass*(dbeta*sin(beta)*L-darfa*(sin(arfa)*(x_A-x_B)+cos(arfa)*(y_A-y_B)));
Mass*(-dbeta*cos(beta)*L+darfa*(cos(arfa)*(x_A-x_B)-sin(arfa)*(y_A-y_B)));
                                                                 I_C*dbeta;
                                                1/2*mass*dbeta*sin(beta)*L;
                                               -1/2*mass*dbeta*cos(beta)*L];
   
 XX=inv(AA)*BB
 
 friction=abs(XX(4)/XX(3))
 flag_next=0;
       XYZ(1)=arfa;
       XYZ(2)=beta;
       XYZ(3)=darfa;
       XYZ(4)=dbeta;

 if(friction<mu0)
     if(XX(3)>0)
       disp('--------------2Ħ������ϸ�װ���������������----------')
       flag_next=1;   
       XYZ(1)=arfa;
       XYZ(2)=beta;
       XYZ(3)=XX(1);
       XYZ(4)=XX(2);
   end
 end
  
 if(friction>mu0)
       disp('******2Ħ��ϵ�����������ܻ�򻬣����������������鲻�ϸ񣡣�������-----')
 end
  if(XX(3)<0)
       disp('******2ѹ��С���㣬�����ì�ܣ����鲻�ϸ񣡣�������-----')
 end
 
