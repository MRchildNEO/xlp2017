function [EE,TT]=energy_all(t,xyz,index)
global theta R L alpha0 bata0 V000
global x_A y_A x_B y_B Mass mass I_A I_C g theta_OB L_AB L_OA  L_OB theta_AEO

[row,col]=size(xyz);

for ii=1:row
  alpha=xyz(ii,1);
  beta=xyz(ii,2);
  dalpha=xyz(ii,3);
  dbeta=xyz(ii,4);
  
  if(index==2)
E1=1/2*Mass*(L^2*dbeta^2+(x_A^2-2*x_A*x_B+x_B^2+y_A^2-2*y_A*y_B+y_B^2)*dalpha^2+2*L*(x_A^2-2*x_A*x_B+x_B^2+y_A^2-2*y_A*y_B+y_B^2)^(1/2)*dbeta*dalpha*cos(-beta+alpha))+1/2*I_A*dalpha^2;
E2=1/6*mass*L^2*dbeta^2;
E3=Mass*g*(-(x_A^2-2*x_A*x_B+x_B^2+y_A^2-2*y_A*y_B+y_B^2)^(1/2)*sin(-beta+theta)-(x_A^2-2*x_A*x_B+x_B^2+y_A^2-2*y_A*y_B+y_B^2)^(1/2)*sin(-alpha+theta));
E4=-1/2*mass*g*(x_A^2-2*x_A*x_B+x_B^2+y_A^2-2*y_A*y_B+y_B^2)^(1/2)*sin(-beta+theta);
if(ii==1)
    dvvv=V000-E3-E4
end
EE(ii)=E3+E4+dvvv;
TT(ii)=E1+E2;
else
E1=                                             1/2*Mass*dalpha^2*(-R-sin(alpha)*x_A-cos(alpha)*y_A)^2+1/2*Mass*dalpha^2*(cos(alpha)*x_A-sin(alpha)*y_A)^2+1/2*I_A*dalpha^2;
E2=1/2*mass*(dalpha*(-R-sin(alpha)*x_B-cos(alpha)*y_B)-1/2*dbeta*sin(beta)*L)^2+1/2*mass*(dalpha*(cos(alpha)*x_B-sin(alpha)*y_B)+1/2*dbeta*cos(beta)*L)^2+1/2*I_C*dbeta^2;
E3=                                                        Mass*g*(-sin(theta)*(-R*(alpha-alpha0)+cos(alpha)*x_A-sin(alpha)*y_A)+cos(theta)*(sin(alpha)*x_A+cos(alpha)*y_A));
E4=                        mass*g*(-sin(theta)*(-R*(alpha-alpha0)+cos(alpha)*x_B-sin(alpha)*y_B+1/2*cos(beta)*L)+cos(theta)*(sin(alpha)*x_B+cos(alpha)*y_B+1/2*sin(beta)*L));
if(ii==1)
    dvvv=V000-E3-E4
end
EE(ii)=E3+E4+dvvv;
TT(ii)=E1+E2;

end
end

