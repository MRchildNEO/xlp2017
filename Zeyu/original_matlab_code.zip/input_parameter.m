function input_parameter

global theta R L alpha0 beta0 SIDES
global x_A y_A x_B y_B Mass mass I_A I_C g
global shapex0 shapey0 x_A0 y_A0 x_B0 y_B0 Xaxis_x0 Xaxis_y0 Yaxis_x0 Yaxis_y0

%%%%%%%%%%%%%%%%%%%%

% װ�õļ�����״
for ii=1:SIDES+1
    shapex0(ii)=-R*cos(pi*(ii-1)/SIDES);
    shapey0(ii)=-R*sin(pi*(ii-1)/SIDES);     
end
    shapex0(SIDES+2)=shapex0(1);
    shapey0(SIDES+2)=shapey0(1);     

% A���BC���λ��    
    x_A0=x_A;
    y_A0=y_A;
    
    x_B0(1)=x_B;
    y_B0(1)=y_B;
    
    
% ����ϵ
   Xaxis_x0(1)=0;
   Xaxis_y0(1)=0;
   Xaxis_x0(2)=0+2*R;
   Xaxis_y0(2)=0;
   
   Yaxis_x0(1)=0;
   Yaxis_y0(1)=0;
   Yaxis_x0(2)=0;
   Yaxis_y0(2)=0+2*R;