function [Shapex,Shapey,Xaxis_x,Xaxis_y,Yaxis_x,Yaxis_y,X_A,Y_A,X_B,Y_B]=solve_rotate_body2(xyz) 

global theta R L SIDES alpha0 beta0
global x_A y_A x_B y_B Mass mass I_A I_C g pointD_x pointD_y
global L_AB L_OA L_OB theta_ABO theta_BOE theta_AEO
global shapex0 shapey0 x_A0 y_A0 x_B0 y_B0 Xaxis_x0 Xaxis_y0 Yaxis_x0 Yaxis_y0 
global xx_center yy_center x00
%------------ת�����װ��

[row,col]=size(xyz);
    

for ii=1:row
    alpha=xyz(ii,1)-theta_AEO;
    beta=xyz(ii,2)-pi;
    
    x_center=0;
    y_center=0;

A_Xx=[cos(alpha-theta),-sin(alpha-theta);sin(alpha-theta),cos(alpha-theta)];

[shapex,shapey]=solve_rotate_position(shapex0,shapey0,x_center,y_center,A_Xx);
[xaxis_x,xaxis_y]=solve_rotate_position(Xaxis_x0,Xaxis_y0,x_center,y_center,A_Xx);
[yaxis_x,yaxis_y]=solve_rotate_position(Yaxis_x0,Yaxis_y0,x_center,y_center,A_Xx);
[xx_A,yy_A]=solve_rotate_position(x_A0,y_A0,x_center,y_center,A_Xx);
[xx_B,yy_B]=solve_rotate_position(x_B0,y_B0,x_center,y_center,A_Xx);

xx_B(2)=xx_B(1)+L*cos(beta-theta);
yy_B(2)=yy_B(1)+L*sin(beta-theta);

ddx=(pointD_x-xx_B(2));
ddy=(pointD_y-yy_B(2));
%--------------
   for jjj=1:SIDES+2
        Shapex(ii,jjj)=shapex(jjj)+ddx;
        Shapey(ii,jjj)=shapey(jjj)+ddy;
    end
    for jjj=1:2
        Xaxis_x(ii,jjj)=xaxis_x(jjj)+ddx;
        Xaxis_y(ii,jjj)=xaxis_y(jjj)+ddy;
        Yaxis_x(ii,jjj)=yaxis_x(jjj)+ddx;
        Yaxis_y(ii,jjj)=yaxis_y(jjj)+ddy;
        X_B(ii,jjj)=xx_B(jjj)+ddx;
        Y_B(ii,jjj)=yy_B(jjj)+ddy;
   end
        X_A(ii)=xx_A+ddx;
        Y_A(ii)=yy_A+ddy;
end

xx_center=Xaxis_x(row,1);
yy_center=Xaxis_y(row,1);
alpha0=alpha;


A_XK=[cos(theta),-sin(theta),0;sin(theta),cos(theta),0;0,0,1];

rooK=[Xaxis_x(row,1);Xaxis_y(row,1);0];
rooX=A_XK*rooK;

x00=rooX(1);
