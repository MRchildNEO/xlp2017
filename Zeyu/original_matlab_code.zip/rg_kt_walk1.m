%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%   ���΢�ַ���                                   %%%
%%%   ���������ʱ��t�����̵Ľ�y                     %%%
%%%   ���㹫ʽ��΢�ַ��̵ľ������ʽ                 %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ydot=rg_kt_walk1(t,y)
global theta R L alpha0 beta0 
global x_A y_A x_B y_B Mass mass I_A I_C g


ydot=zeros(4,1);

% y1=alpha y2=beta y3=dalpha/dt y4=dbeta/dt
   ydot(1)=y(3);
   ydot(2)=y(4);

   
alpha=y(1);
beta=y(2);
dalpha=y(3);
dbeta=y(4);

kk=[                                                                                                                                                                                                                              mass*y_B^2+mass*x_B^2+Mass*y_A^2+Mass*x_A^2+Mass*R^2+mass*R^2+I_A+2*Mass*R*cos(alpha)*y_A+2*mass*R*cos(alpha)*y_B+2*Mass*R*sin(alpha)*x_A+2*mass*R*sin(alpha)*x_B;
                                                                                                                                                                                                                                                                                                          -1/2*sin(alpha-beta)*y_B*L*mass+1/2*sin(beta)*L*mass*R+1/2*x_B*L*cos(alpha-beta)*mass;
 (Mass*dalpha^2*R*cos(alpha)+Mass*g*cos(theta-alpha))*x_A+mass*g*sin(theta)*R+Mass*g*sin(theta)*R+mass*g*x_B*cos(theta-alpha)+mass*g*y_B*sin(theta-alpha)+mass*dalpha^2*cos(alpha)*x_B*R+Mass*g*y_A*sin(theta-alpha)+1/2*mass*dbeta^2*cos(beta)*L*R-Mass*dalpha^2*R*sin(alpha)*y_A+1/2*mass*dbeta^2*L*y_B*cos(alpha-beta)-mass*dalpha^2*sin(alpha)*y_B*R+1/2*mass*dbeta^2*L*x_B*sin(alpha-beta);
                                                                                                                                                                                                                                                                                                           1/2*mass*sin(beta)*L*R+1/2*mass*L*x_B*cos(alpha-beta)-1/2*mass*L*y_B*sin(alpha-beta);
                                                                                                                                                                                                                                                                                                                                                                               1/4*mass*L^2+I_C;
                                                                                                                                                                                                                                                                                                      1/2*mass*L*(-sin(alpha-beta)*x_B*dalpha^2-cos(alpha-beta)*y_B*dalpha^2+g*cos(theta-beta))];
 

AA=[kk(1),kk(2);kk(4),kk(5)];
BB=-[kk(3);kk(6)];
XX=inv(AA)*BB;

  ydot(3)=XX(1);
  ydot(4)=XX(2);
 

