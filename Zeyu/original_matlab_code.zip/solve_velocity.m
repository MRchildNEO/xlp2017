function [r_AB_X,v_A,v_C,Angle]=solve_velocity(xyz)
global theta R L alpha0 beta0
global x_A y_A x_B y_B 

row=length(xyz);

alpha=xyz(row,1);
beta=xyz(row,2);
dalpha=xyz(row,3);
dbeta=xyz(row,4);

%----------------
Angle(1)=alpha;
Angle(2)=beta;
Angle(3)=dalpha;
Angle(4)=dbeta;

%---------------------
A_Xx=[cos(alpha),-sin(alpha);sin(alpha),cos(alpha)];
A_Xx1=[cos(beta),-sin(beta);sin(beta),cos(beta)];

dA_Xx=[-sin(alpha),-cos(alpha);cos(alpha),-sin(alpha)]*dalpha;
dA_Xx1=[-sin(beta),-cos(beta);cos(beta),-sin(beta)]*dbeta;

%---------���ι�ϵ
r_oA_x=[x_A;y_A];
r_oB_x=[x_B;y_B];
r_BC_x1=[L/2;0];
r_BD_x1=[L;0];

r_Oo_X=[-R*(alpha-alpha0);0];
r_OA_X=r_Oo_X+A_Xx*r_oA_x;
r_OB_X=r_Oo_X+A_Xx*r_oB_x;
r_OC_X=r_OB_X+A_Xx1*r_BC_x1;
r_OD_X=r_OB_X+A_Xx1*r_BD_x1;

r_AB_X=r_OB_X-r_OA_X;   %from A to B
%---------�ٶȹ�ϵin OXY
v_o=([-R*dalpha;0]);
v_A=v_o+dA_Xx*r_oA_x;
v_C=v_o+dA_Xx*r_oB_x+dA_Xx1*r_BC_x1;
