function draw_it(Shapex,Shapey,Xaxis_x,Xaxis_y,Yaxis_x,Yaxis_y,X_A,Y_A,X_B,Y_B)
global theta R  pause_time back_x front_x
global stop1 stop2 PART_NUM

NN=length(X_A);
% if(PART_NUM==1)
%     stop1=1;
%     stop2=NN;
% end

A_KX=[cos(theta),sin(theta);-sin(theta),cos(theta)];
rb_X=[back_x*R;-R];
rb_K=A_KX*rb_X;
x_border(1)=rb_K(1);
y_border(1)=rb_K(2);

rb_X=[front_x*R;-R];
rb_K=A_KX*rb_X;
x_border(2)=rb_K(1);
y_border(2)=rb_K(2);
plot(x_border,y_border,'k');
hold on;


axis('equal')

h1=patch(Shapex,Shapey,'y','EdgeColor','r','EraseMode','xor');                      %Բ��
h2=line('Color','g','LineStyle','-','EraseMode','xor');                             %X��
h3=line('Color','g','LineStyle','-','EraseMode','xor');                             %Y��
h4=line('Color','r','LineStyle','-','Marker','o','Markersize',10,'EraseMode','xor');%A��
h5=line('Color','b','LineStyle','-','LineWidth',4,'EraseMode','xor');               %BC��
 
% for ii=stop1:stop2
for ii=1:NN
         set(h1,'XData',Shapex(ii,:),'YData',Shapey(ii,:));  %Բ�̵��˶�
         set(h2,'XData',Xaxis_x(ii,:),'YData',Xaxis_y(ii,:));%X����˶�
         set(h3,'XData',Yaxis_x(ii,:),'YData',Yaxis_y(ii,:));%Y����˶�
         set(h4,'XData',X_A(ii),'YData',Y_A(ii));            %Բ������A����˶�
         set(h5,'XData',X_B(ii,:),'YData',Y_B(ii,:));        %BC�˵��˶�
        drawnow;                                             %����ǰ��ͼ 
        pause(pause_time);                                   %ÿ֡�����ĳ���ʱ��[s] 
end

