function [newpx,newpy]=solve_rotate_position(px,py,x_center,y_center,A)
row=length(px);

for kk=1:row
    xyz(1)=px(kk);
    xyz(2)=py(kk);

    newxyz=A*xyz';
    
    newpx(kk)=x_center+newxyz(1);
    newpy(kk)=y_center+newxyz(2);
end