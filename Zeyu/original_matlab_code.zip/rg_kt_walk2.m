%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%   ���΢�ַ���      ��2�׶Σ�װ����������        %%%
%%%   ���������ʱ��t�����̵Ľ�y                     %%%
%%%   ���㹫ʽ��΢�ַ��̵ľ������ʽ                 %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function ydot=rg_kt_walk2(t,y)

global theta R L 
global Mass mass I_A I_C g 
global x_A y_A x_B y_B Mass mass I_A I_C g pointD_x pointD_y
global L_AB L_OA L_OB theta_ABO theta_BOE theta_AEO

ydot=zeros(4,1);

% y1=gamma y2=beta y3=dgamma/dt y4=dbeta/dt
   ydot(1)=y(3);
   ydot(2)=y(4);

   
gamma=y(1);
yita=y(2);
dgamma=y(3);
dyita=y(4);


cc=[                                                                              Mass*L_AB^2+I_A;
                                                                  Mass*L*L_AB*cos(yita-gamma);
                                    Mass*L_AB*(-L*dyita^2*sin(yita-gamma)+g*cos(gamma-theta));
                                                                  Mass*L*L_AB*cos(yita-gamma);
                                                                        Mass*L^2+1/3*mass*L^2;
 1/2*L_AB*(2*Mass*L*dgamma^2*sin(yita-gamma)+2*Mass*cos(yita-theta)*g+mass*g*cos(yita-theta))];
     

AA=[cc(1),cc(2);cc(4),cc(5)];
BB=-[cc(3);cc(6)];
XX=inv(AA)*BB;

  ydot(3)=XX(1);
  ydot(4)=XX(2);
 

