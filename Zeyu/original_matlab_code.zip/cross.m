function rc=cross(ra,rb);

cross_ra=[0 -ra(3) ra(2);
         ra(3) 0 -ra(1);
         -ra(2) ra(1) 0];
     
rrb(1,1)=rb(1);
rrb(2,1)=rb(2);
rrb(3,1)=rb(3);
     
     rc=cross_ra*rrb;