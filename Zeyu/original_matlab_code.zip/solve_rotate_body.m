function [Shapex,Shapey,Xaxis_x,Xaxis_y,Yaxis_x,Yaxis_y,X_A,Y_A,X_B,Y_B]=solve_rotate_body(xyz) 

global theta R L SIDES alpha0 beta0
global x_A y_A x_B y_B Mass mass I_A I_C g pointD_x pointD_y
global shapex0 shapey0 x_A0 y_A0 x_B0 y_B0 Xaxis_x0 Xaxis_y0 Yaxis_x0 Yaxis_y0
global xx_center yy_center x00
%------------ת�����װ��
% alphaװ�õĶ������б���ת�� [rad]
% beta�ڸ����б���ת�� [rad]

[row,col]=size(xyz);
    
for ii=1:row
    alpha=xyz(ii,1);
    beta=xyz(ii,2);
    A_KX=[cos(theta),sin(theta);-sin(theta),cos(theta)];
    rc_X=[-R*(alpha-alpha0)+x00;0];
    rc_K=A_KX*rc_X;
    x_center=rc_K(1);
    y_center=rc_K(2);

A_Xx=[cos(alpha-theta),-sin(alpha-theta);sin(alpha-theta),cos(alpha-theta)];

[shapex,shapey]=solve_rotate_position(shapex0,shapey0,x_center,y_center,A_Xx);
[xaxis_x,xaxis_y]=solve_rotate_position(Xaxis_x0,Xaxis_y0,x_center,y_center,A_Xx);
[yaxis_x,yaxis_y]=solve_rotate_position(Yaxis_x0,Yaxis_y0,x_center,y_center,A_Xx);
[xx_A,yy_A]=solve_rotate_position(x_A0,y_A0,x_center,y_center,A_Xx);
[xx_B,yy_B]=solve_rotate_position(x_B0,y_B0,x_center,y_center,A_Xx);

xx_B(2)=xx_B(1)+L*cos(beta-theta);
yy_B(2)=yy_B(1)+L*sin(beta-theta);

%--------------
   for jjj=1:SIDES+2
        Shapex(ii,jjj)=shapex(jjj);
        Shapey(ii,jjj)=shapey(jjj);
   end
   for jjj=1:2
        Xaxis_x(ii,jjj)=xaxis_x(jjj);
        Xaxis_y(ii,jjj)=xaxis_y(jjj);
        Yaxis_x(ii,jjj)=yaxis_x(jjj);
        Yaxis_y(ii,jjj)=yaxis_y(jjj);
        X_B(ii,jjj)=xx_B(jjj);
        Y_B(ii,jjj)=yy_B(jjj);
   end
        X_A(ii)=xx_A;
        Y_A(ii)=yy_A;
end

pointD_x=X_B(row,2);
pointD_y=Y_B(row,2);

% xx_center=Xaxis_x(row,1);
% yy_center=Xaxis_y(row,1);
